<?php

	header('location: views/login.html');

?>