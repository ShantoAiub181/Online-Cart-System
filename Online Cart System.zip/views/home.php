<?php 

	include('header.php');

?>

<html>
<head>
	<title>Home page</title>
	<link rel="stylesheet" type="text/css" href="home.css">
</head>
<body>
	<div class="banner" class="logo">
		<div class="navbar">
			<ul>
				<a href="Profile.html">Profile</a><br>
				<a href="Product.html">Product</a><br>
				<a href="contact admin.html">Contact Admin</a><br>
				<a href="data analytics.html">Data Analytics</a><br>
				<a href="Customer Information.html">Customer Information</a><br>
				<a href="userlist.php">User List</a><br>
				<a href="../controller/logout.php">Logout</a><br>
			</ul>
		</div>
	</div>
</body>
</html>